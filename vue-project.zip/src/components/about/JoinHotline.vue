<template>
    <div class="joinHotline">
        <img src="@/assets/logo2.png" alt="">
        <p>加盟热线：400-035-2688</p>
        <p>官方网站： http://www.k2688.com</p>
    </div>
</template>

<script>
export default {
    name:'joinHotline'
}
</script>

<style scoped>
.joinHotline{
    text-align: center;
    font-size: 22px;
    line-height: 2;
    padding:30px 0;
}
.joinHotline img{
    margin-bottom:20px;
    max-width: 250px;
    width:60%;
}
@media screen and (max-width:1000px){    
    .joinHotline{
        font-size:.3rem;
        padding:.3rem 0;
    }
}
</style>
